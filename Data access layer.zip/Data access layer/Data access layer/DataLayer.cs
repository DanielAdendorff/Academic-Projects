﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Data_access_layer
{
    internal class Datalayer
    {
        static void Main(string[] args)
        {
        }

        class dataRetrieval
        {

            string connectionString = "Data Source=YourServer;Initial Catalog=YourDatabase;User ID=YourUsername;Password=YourPassword";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sqlQuery = "SELECT * FROM YourTable";
            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Access the data from the reader based on the columns in the query
                        int id = reader.GetInt32(0); // Assuming the first column is an integer
    string name = reader.GetString(1); // Assuming the second column is a string

    Console.WriteLine($"ID: {id}, Name: {name}");
                    }
                
            
       

            //this class will be used to recieve the data from the dbd/text file
        

        class output
        {
    //this class will be used to convert the data from the txt file/dbd into values for the code
    static void Main()
    {
        string connectionString = "Data Source=YourServer;Initial Catalog=YourDatabase;User ID=YourUsername;Password=YourPassword";

        List<Person> people = new List<Person>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string sqlQuery = "SELECT Id, FirstName, LastName FROM Persons";
            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string firstName = reader.GetString(1);
                        string lastName = reader.GetString(2);

                        Person person = new Person
                        {
                            Id = id,
                            FirstName = firstName,
                            LastName = lastName
                        };

                        people.Add(person);
                    }
                }
            }
        }

        // Now, you have a list of C# objects representing data from the database.
        foreach (var person in people)
        {
            Console.WriteLine($"ID: {person.Id}, Name: {person.FirstName} {person.LastName}");
        }
    }
}

public class Person
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
}


class DataStorage
{
    //this class will be used to modify the data by turning the user input into sql
    string connectionString = "Data Source=YourServer;Initial Catalog=YourDatabase;User ID=YourUsername;Password=YourPassword";
    
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string firstName = "John"; // Replace with your data
    string lastName = "Doe"; // Replace with your data

    string sqlQuery = "INSERT INTO YourTable (FirstName, LastName) VALUES (@FirstName, @LastName)";

                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
{
    // Use parameters to prevent SQL injection
    command.Parameters.AddWithValue("@FirstName", firstName);
    command.Parameters.AddWithValue("@LastName", lastName);

    int rowsAffected = command.ExecuteNonQuery();

    if (rowsAffected > 0)
    {
        Console.WriteLine("Data inserted successfully.");
    }
    else
    {
        Console.WriteLine("Data insertion failed.");
    }
}

        catch (Exception ex)
        {
    Console.WriteLine("An error occurred: " + ex.Message);
}



        

    

