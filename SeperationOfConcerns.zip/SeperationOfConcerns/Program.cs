﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeperationOfConcerns
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataHandler handler = new DataHandler();
            handler.RunApp();

            Console.ReadLine();
        }
    }
}
