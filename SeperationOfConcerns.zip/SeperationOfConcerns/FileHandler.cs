﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;        //Import IO Namespace

namespace SeperationOfConcerns
{
    internal class FileHandler  //Handles all File I/O Operations
    {
        //Read student data from the text file
        public List<string> readFile()
        {
            List<string> studentData = new List<string>();

            //read each line from file and store in list
            studentData = File.ReadAllLines("StudentData.txt").ToList();
            foreach (string line in studentData) 
            {
                Console.WriteLine(line);
            }
            
            return studentData;
        }

        //Write student data to word file  (simulating)
        public void WriteStudentData()
        {
            List<string> output = new List<string>();
            DataHandler handler = new DataHandler();

            foreach (var item in handler.formatData())  //Invoke formatData function
            {
                output.Add(item.ToString()); //Store formatted data in list
            }

            foreach (string line in output)
            {
                Console.WriteLine(line);    //Display formatted data
            }

            Console.WriteLine();
            File.WriteAllLines("formatted.txt", output);    //Write formatted data to file
            Console.WriteLine("Written formatted data to word file");
            Console.WriteLine("Please check folder");
        }
    }
}
