﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeperationOfConcerns
{
    internal class Student //Student details
    {
        //Fields
        string name, surname, course;
        int age;

        //Properties
        public string Name { get { return name; } }
        public string Surname { get { return surname; } }
        public int Age { get { return age; } }
        public string Course { get { return course; } }

        //Constructor
        public Student(string n, string s, int a, string c)
        {
            this.name = n;
            this.surname = s;
            this.course = c;
            this.age = a;
        }

        public override string ToString()
        {
            return $"FirstName: {this.name} | Surname: {this.surname} | Course: {this.course} | Age: {this.age}";
        }
    }
}





