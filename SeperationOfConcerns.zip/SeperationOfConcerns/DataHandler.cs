﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeperationOfConcerns
{
    internal class DataHandler
    {
        

        //We want to split each line in list to seperate fields (name, surname, age and course)
        public List<Student> formatData()
        {
            List<Student> students = new List<Student>();
            FileHandler handler = new FileHandler();
      
            foreach (var line in handler.readFile())
            {
                string[] item = line.Split(',');
                if (item.Length >= 4) 
                {
                    students.Add(new Student(item[0], item[1], int.Parse(item[2]), item[3]));
                }
            }
            return students;
        }

        //Operation to run the app
        public void RunApp()
        {
            FileHandler handler = new FileHandler();
            handler.WriteStudentData();
        }
      
    }
}


