﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListObject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>();

            students.Add(new Student("Tom", "Madwe", "Degree", 22));
            students.Add(new Student("Alice", "Smith", "Degree", 21));
            students.Add(new Student("Sipho", "Zuma", "Diploma", 22));
            students.Add(new Student("Andries", "van Vyk", "Certficate", 20));
            int count = 1;

            foreach (Student student in students)
            {
                Console.WriteLine($"Student {count} details");
                Console.WriteLine(student.ToString());
                Console.WriteLine(); 
                count++;
            }

            Console.ReadLine();
        }
    }
}
