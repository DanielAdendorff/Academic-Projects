﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListObject
{
    internal class Student
    {
        //Student details
        //Fields
        string name, surname, course;
        int age;

        //Constructors
        public Student() { }

        public Student(string n, string s, string c, int a)
        {
            this.name = n;
            this.surname = s;
            this.course = c;
            this.age = a;
        }

        public override string ToString()
        {
            return $"FirstName: {this.name} | Surname: {this.surname} | Age: {this.age} | Course: {this.course}";
        }
    }
}


