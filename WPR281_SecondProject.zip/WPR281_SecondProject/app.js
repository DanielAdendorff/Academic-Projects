function validateForm() {
    // Validation for First Name (letters only)
    var firstNameInput = document.getElementById("firstName");
    var firstNameValue = firstNameInput.value.trim();
    var namePattern = /^[A-Za-z]+$/;
  
    if (!namePattern.test(firstNameValue)) {
      // Display error message or visual effect for invalid input
      alert("First Name must contain letters only.");
      firstNameInput.focus();
      return false;
    }
  
    // Validation for Last Name (letters only)
    var lastNameInput = document.getElementById("lastName");
    var lastNameValue = lastNameInput.value.trim();
  
    if (!namePattern.test(lastNameValue)) {
      // Display error message or visual effect for invalid input
      alert("Last Name must contain letters only.");
      lastNameInput.focus();
      return false;
    }
  
    // Validation for Phone Number (xxx-xxxx format)
    var phoneNumberInput = document.getElementById("phoneNumber");
    var phoneNumberValue = phoneNumberInput.value.trim();
    var phonePattern = /^\d{3}-\d{4}$/;
  
    if (!phonePattern.test(phoneNumberValue)) {
      // Display error message or visual effect for invalid input
      alert("Phone Number must be in the format xxx-xxxx.");
      phoneNumberInput.focus();
      return false;
    }
  
    // Validation for Country (at least three options)
    var countryInput = document.getElementById("country");
    var selectedCountry = countryInput.value;
  
    if (selectedCountry === "") {
      // Display error message or visual effect for invalid input
      alert("Please select a valid Country.");
      countryInput.focus();
      return false;
    }
  
    // Validation for Gender (at least three options)
    var genderInput = document.getElementById("gender");
    var selectedGender = genderInput.value;
  
    if (selectedGender === "") {
      // Display error message or visual effect for invalid input
      alert("Please select a valid Gender.");
      genderInput.focus();
      return false;
    }
  
    // If all validations pass, hide the form and display the summary
    document.getElementById("registrationForm").style.display = "none";
    document.getElementById("summary").style.display = "block";
  
    // Code to display the summary of entered information goes here
    // You can use the entered values and populate the "summary" div with the information.
    // For example, you can create a summary string and set it as the innerHTML of the "summary" div.
  
    return false; // Prevent form submission (since we are showing the summary instead)

    
  }