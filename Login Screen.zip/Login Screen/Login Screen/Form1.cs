﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Screen
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        DataHandler dh = new DataHandler();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                // Get user information from textboxes
                string username = Username.Text;
                string email = password.Text;

                // Validate input (you may want to add more validation)
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Please enter both username and email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Construct the user information string
                string userInfo = $"{username},{email}";

                // Specify the path to the text file
                string filePath = "user_data.txt";

                // Write user information to txt file
                try
                {
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine(userInfo);
                    }

                    MessageBox.Show("Signup successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Optionally, clear textboxes after signup
                    password.Text = "";
                    Username.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error writing to file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    

            private void button1_Click(object sender, EventArgs e)
            {
            //get the logins and see whether they are valid or not
                dt = dh.getLogins();
                bool found = false;
            //go through the txt file rows
                foreach (DataRow row in dt.Rows)
                {
                    if (row[1].ToString() == Username.Text)
                    {
                        if (row[2].ToString() == password.Text)
                        {
                            MessageBox.Show("Login Successfull");
                            Form2 frm2 = new Form2(this);
                            frm2.ShowDialog();
                            this.Hide();
                            found = true;
                        }

                    }
                }
                //validating that it has been found
                if (!found)
                {
                    MessageBox.Show("User not found");
                }

            }

            private void Form1_FormClosing(object sender, FormClosingEventArgs e)
            {
                Application.Exit();
            }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
}
