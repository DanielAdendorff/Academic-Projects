﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282_Project.DataLayer
{
    internal class Datahandler
    {
        SqlConnection conn = new SqlConnection("Server = MY-HP\\SQLEXPRESS; Initial Catalog = Student_Info; Integrated Security = SSPI");

        public BindingSource readData (string qry)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(qry, conn);
            SqlDataReader reader  = cmd.ExecuteReader();
            BindingSource src = new BindingSource();
            src.DataSource = reader;

            conn.Close();
            return src;
        }
        public void UploadImage(string ID, DataGridView dgv)

        {

            string Image_Path = "";

            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Filter = "PNG Files(*.png)|*.png|All Files(*.*)|*.*";

            if (dialog.ShowDialog() == DialogResult.OK)

            {

                string picturePath = dialog.FileName.ToString();

                Image_Path = picturePath;

            }

            if (Image_Path != "")

            {

                byte[] imageBt = null;

                FileStream fstream = new FileStream(Image_Path, FileMode.Open, FileAccess.Read);

                BinaryReader br = new BinaryReader(fstream);

                imageBt = br.ReadBytes((int)fstream.Length);

                string qry = @"UPDATE STUDENTS SET ST_Image =" + "@IMG \n WHERE StudentID= " + ID;

                SqlCommand cmd = new SqlCommand(qry, conn);

                SqlDataReader reader;

                if (ID != "")

                {
                    try

                    {

                        conn.Open();

                        cmd.Parameters.Add(new SqlParameter("@IMG", imageBt));

                        reader = cmd.ExecuteReader();

                        MessageBox.Show("Inserted image");

                        conn.Close();

                        Image_Path = "";

                        dgv.DataSource = readData("SELECT * FROM Students");

                    }

                    catch (Exception e)

                    {

                        MessageBox.Show(e.Message);

                    }

                }

                else

                {

                    MessageBox.Show("Please select a item in Data Grid");

                }

                dgv.AutoResizeRows();

            }

        }

        //shorten version for update, insert and delete for Student Info, just select the type of query you want 
        public void CRUD_Procedures(SqlCommand cmd)
        {
          
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public void CRUD_Procedures2(string query)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public void AddModule(string moduleCode, string moduleName, string moduleDescription, string sourceLink)
        {
            string query = "EXEC AddModule @Module_Code, @Module_Name, @Module_Description, @Source_Link";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);
                cmd.Parameters.AddWithValue("@Module_Name", moduleName);
                cmd.Parameters.AddWithValue("@Module_Description", moduleDescription);
                cmd.Parameters.AddWithValue("@Source_Link", sourceLink);

                CRUD_Procedures(cmd);
            }
        }

        public void UpdateModule(string moduleCode, string moduleName, string moduleDescription, string sourceLink)
        {
            string query = "EXEC UpdateModule @Module_Code, @Module_Name, @Module_Description, @Source_Link";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);
                cmd.Parameters.AddWithValue("@Module_Name", moduleName);
                cmd.Parameters.AddWithValue("@Module_Description", moduleDescription);
                cmd.Parameters.AddWithValue("@Source_Link", sourceLink);

                CRUD_Procedures(cmd);
            }
        }

        public void DeleteModule(string moduleCode)
        {
            string query = "EXEC DeleteModule @Module_Code";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);

                CRUD_Procedures(cmd);
            }
        }
        public void AddStudent(int studentNumber, string name, string surname, string dateOfBirth, string gender, string phone, string address, string moduleCode, byte[] stImage)
        {
            string query = "EXEC AddStudent @Student_Number, @Name, @Surname, @DateOfBirth, @Gender, @Phone, @Address, @Module_Code, @ST_Image";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Student_Number", studentNumber);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Surname", surname);
                cmd.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);
                cmd.Parameters.AddWithValue("@ST_Image", stImage);

                CRUD_Procedures(cmd);
            }
        }
        public void AddStudent2(int studentNumber, string name, string surname, string dateOfBirth, string gender, string phone, string address, string moduleCode)
        {
            string query = "EXEC AddStudent2 @Student_Number, @Name, @Surname, @DateOfBirth, @Gender, @Phone, @Address, @Module_Code";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Student_Number", studentNumber);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Surname", surname);
                cmd.Parameters.AddWithValue("@DateOfBirth", dateOfBirth);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);
                

                CRUD_Procedures(cmd);
            }
        }

        public void UpdateStudent(int studentNumber, string name, string surname, string gender, string phone,string moduleCode)
        {
            string query = "EXEC UpdateStudent2 @Student_Number, @Name, @Surname,@Gender, @Phone, @Module_Code";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Student_Number", studentNumber);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Surname", surname);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@Module_Code", moduleCode);

                CRUD_Procedures(cmd);
            }
        }

        public void DeleteStudent(int studentNumber)
        {
            string query = "EXEC DeleteStudent @Student_Number";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Student_Number", studentNumber);

                CRUD_Procedures(cmd);
            }
        }
        public void getModules(ComboBox box)
        {
            SqlCommand cmd = new SqlCommand("Select * from Modules;", conn);
            
            conn.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while ((reader.Read()))
                {
                    box.Items.Add(reader[0].ToString());
                }
            }
            conn.Close();
        }


    }
}
