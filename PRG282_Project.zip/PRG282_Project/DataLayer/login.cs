﻿namespace PRG282_Project.DataLayer
{
    internal class login
    {
        public string Username { get; internal set; }
        public string Password { get; internal set; }
    }
}