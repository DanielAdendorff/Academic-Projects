﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_Project.DataLayer;

namespace PRG282_Project.BusinessLogicLayer
{
    internal class Students
    {
        //Fields and Properies
        public int studentNo { get; set; }
        public string studentName { get; set; }
        public string studentSurname { get; set; }
        public DateTime studentDOB { get; set; }
        public string studentGender { get; set; }
        public string studentPhone { get; set; }
        public string studentAddress { get; set; }
        public string moduleCode { get; set; }
        public Image studentImage { get; set; }

        //Default constructor
        public Students() { }

        //Constructor with parameters
        public Students(int studentNo, string studentName, string studentSurname, DateTime studentDOB, string studentGender, string studentPhone, string studentAddress, string moduleCode, Image studentImage)
        {
            this.studentNo = studentNo;
            this.studentName = studentName;
            this.studentSurname = studentSurname;
            this.studentDOB = studentDOB;
            this.studentGender = studentGender;
            this.studentPhone = studentPhone;
            this.studentAddress = studentAddress;
            this.moduleCode = moduleCode;
            this.studentImage = studentImage;
        }

        //Create instance of data handler
        Datahandler handler = new Datahandler();

        public void CreateStudent(List<Students> studentDetails) 
        {
            //create query string - insert new values into student table
            string query = $"INSERT INTO Studentz VALUES {studentDetails[0]},{studentDetails[1]}," +
                $"{studentDetails[2]},{studentDetails[3]},{studentDetails[4]},{studentDetails[4]}," +
                $"{studentDetails[5]},{studentDetails[6]},{studentDetails[7]},{studentDetails[8]}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if unable to create new student
                MessageBox.Show("Error - unable to create new student.");
            }
        }

        public void DisplayStudents() 
        {
            //Create query string - view all students
            string query = "SELECT * FROM Studentz";

            try
            {
                //execute query
                handler.readData(query);
            }
            catch (Exception)
            {
                //if unable to display data
                MessageBox.Show("Error - unable to display students.");
            }
        }

        public void UpdateStudent(int studentId, List<Students> updatedDetails) 
        {
            //create query string - update all information of specified student
            string query = $"UPDATE Studentz SET Student_Number = {updatedDetails[0]}, Name = {updatedDetails[1]}," +
                $"Surname = {updatedDetails[2]}, DateOfBirth = {updatedDetails[3].ToString()}, Gender = {updatedDetails[4]}," +
                $"Phone = {updatedDetails[5]}, Address = {updatedDetails[6]}, Module_Code = {updatedDetails[7]}," +
                $"ST_Image = {updatedDetails[8]} WHERE Student_Number = {studentId}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to update
                MessageBox.Show("Error - unable to update student details.");
            }
        }

        public void DeleteStudent(int studentId) 
        {
            //create query string - delete record of specified student
            string query = $"DELETE FROM Studentz WHERE Student_Number = {studentId}";

            try
            {
                //execute query 
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if not able to delete
                MessageBox.Show("Error - unable to delete student.");
            }
        }
        
        public void FindStudent(int studentId) 
        {
            //create query string - select all fields for specified student
            string query = $"SELECT * FROM Studentz WHERE Student_Number = {studentId}";

            try
            {
                //execute query
                handler.CRUD_Procedures2(query);
            }
            catch (Exception)
            {
                //if student is not found
                MessageBox.Show("Error - student not found.");
            }
        }
    }
}
