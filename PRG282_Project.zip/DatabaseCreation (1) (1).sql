Create Database Student_Info;
GO

USE Student_Info;
go

CREATE TABLE Modules (
    Module_Code VARCHAR(50) Primary Key, 
    Module_Name VARCHAR(50) NOT Null,
    Module_Description VARCHAR(50) Not Null ,
    Source_Link VARCHAR(2064)  Not Null
);
GO

CREATE TABLE Studentz (
    Student_Number INT PRIMARY KEY NOT NULL,
    Name VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    DateOfBirth VARCHAR(50) NOT NULL,
    Gender VARCHAR(50) NOT NULL,
    Phone VARCHAR(50) NOT NULL,
    Address VARCHAR(50) NOT NULL,
    Module_Code VARCHAR(50) REFERENCES  Modules(Module_Code),
	ST_Image VARBINARY(MAX)
);
GO

INSERT INTO Modules VALUES 
('PRG281', 'Programming 1', 'Learning C#', 'https://www.google.com/search?q=programming&sxsrf=ALiCzsbeiwuvRxZnuCeeIveutJtk7_OwLA:1667840911595&source=lnms&tbm=vid&sa=X&ved=2ahUKEwixgc_Ix5z7AhWSQUEAHZNoB1wQ_AUoA3oECAEQBQ&biw=1920&bih=969&dpr=1#fpstate=ive&vld=cid:b7418bb7,vid:zOjov-2OZ0E'),
('STA181', 'Statistics', 'Probability', 'https://www.youtube.com/watch?v=GUQJ7zMoSCM'),
('MAT282', 'Mathematics', 'Calculus for Dummies', 'https://www.youtube.com/watch?v=w3GV9pumczQ'),
('INF282', 'Information Systems', 'All you need to know about the cloud', 'https://www.youtube.com/watch?v=a9__D53WsUs'),
('WPR181', 'Web Programming', 'Learn how to create websites using JS', 'https://www.youtube.com/watch?v=3JluqTojuME'),
('PMM282', 'Project Management', 'Learn how to manage a project', 'https://www.teamgantt.com/project-management-guide/what-is-project-management'),
('DBD181', 'Database Development', 'Learn how to deal with SQL', 'https://learn.microsoft.com/en-us/events/teched-2012/dbi311');
GO


INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(1, 'Lauren', 'Uitlander', '2000/02/21', 'Female', '084-321-2881', 'Van Riebeeck S', 'PRG281');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(2, 'George', 'Hammond', '2002/06/18', 'Male', '071-532-1232', 'Road street', 'MAT282');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(3, 'Matthew', 'Uitlander', '2000/10/02', 'Female', '073-091-2288', 'Hoogland Street', 'DBD181');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(4, 'Beloved', 'Chased', '2002/04/12', 'Male', '033-385-2455', '7 Avenue street', 'PMM282');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(5, 'Katie', 'Smith', '2003/08/08', 'Male', '084-321-2881', '128 Berg Avenue', 'INF282');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(6, 'Tumi', 'Mayo', '2001/02/05', 'Female', '084-321-2881', '3 Lamda', 'STA181');
INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)VALUES 
(7, 'Kayla', 'Burger', '2002/02/01', 'Female', '084-321-2881', '12 Meyer Street', 'WPR181');

GO
-- CRUD procedures for Modules table

-- Create procedure for adding a new module
CREATE PROCEDURE AddModule
    @Module_Code VARCHAR(50),
    @Module_Name VARCHAR(50),
    @Module_Description VARCHAR(50),
    @Source_Link VARCHAR(2064)
AS
BEGIN
    INSERT INTO Modules (Module_Code, Module_Name, Module_Description, Source_Link)
    VALUES (@Module_Code, @Module_Name, @Module_Description, @Source_Link);
END;

GO
-- Read procedure for retrieving all modules
CREATE PROCEDURE GetModules
AS
BEGIN
    SELECT * FROM Modules;
END;

GO
-- Update procedure for modifying a module's information
CREATE PROCEDURE UpdateModule
    @Module_Code VARCHAR(50),
    @Module_Name VARCHAR(50),
    @Module_Description VARCHAR(50),
    @Source_Link VARCHAR(2064)
AS
BEGIN
    UPDATE Modules
    SET Module_Name = @Module_Name,
        Module_Description = @Module_Description,
        Source_Link = @Source_Link
    WHERE Module_Code = @Module_Code;
END;
GO

-- Delete procedure for removing a module
CREATE PROCEDURE DeleteModule
    @Module_Code VARCHAR(50)
AS
BEGIN
    DELETE FROM Modules WHERE Module_Code = @Module_Code;
END;

GO

-- CRUD procedures for Studentz table

-- Create procedure for adding a new student
CREATE PROCEDURE AddStudent
    @Student_Number INT,
    @Name VARCHAR(50),
    @Surname VARCHAR(50),
    @DateOfBirth VARCHAR(50),
    @Gender VARCHAR(50),
    @Phone VARCHAR(50),
    @Address VARCHAR(50),
    @Module_Code VARCHAR(50),
    @ST_Image VARBINARY(MAX)
AS
BEGIN
    INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code, ST_Image)
    VALUES (@Student_Number, @Name, @Surname, @DateOfBirth, @Gender, @Phone, @Address, @Module_Code, @ST_Image);
END;
GO
-- Read procedure for retrieving all students
CREATE PROCEDURE GetStudents
AS
BEGIN
    SELECT * FROM Studentz;
END;
GO

-- Update procedure for modifying a student's information
CREATE PROCEDURE UpdateStudent2
    @Student_Number INT,
    @Name VARCHAR(50),
    @Surname VARCHAR(50),
    @Gender VARCHAR(50),
    @Phone VARCHAR(50),
    @Module_Code VARCHAR(50)
   
AS
BEGIN
    UPDATE Studentz
    SET Name = @Name,
        Surname = @Surname,
        Gender = @Gender,
        Phone = @Phone,
		Module_Code = @Module_Code
    WHERE Student_Number = @Student_Number;
END;
GO

-- Delete procedure for removing a student
CREATE PROCEDURE DeleteStudent
    @Student_Number INT
AS
BEGIN
    DELETE FROM Studentz WHERE Student_Number = @Student_Number;
END;
GO
GO
CREATE PROCEDURE AddStudent2
    @Student_Number INT,
    @Name VARCHAR(50),
    @Surname VARCHAR(50),
    @DateOfBirth VARCHAR(50),
    @Gender VARCHAR(50),
    @Phone VARCHAR(50),
    @Address VARCHAR(50),
    @Module_Code VARCHAR(50)
AS
BEGIN
    INSERT INTO Studentz (Student_Number, Name, Surname, DateOfBirth, Gender, Phone, Address, Module_Code)
    VALUES (@Student_Number, @Name, @Surname, @DateOfBirth, @Gender, @Phone, @Address, @Module_Code);
END;