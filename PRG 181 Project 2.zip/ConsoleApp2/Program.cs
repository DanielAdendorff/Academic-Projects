﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7 { 
    class Program { 

        public static int Totle_order = 0,
            topay = 0,
            topay1,
            breakfastspecial,
            quantity_breakfastspecial,
            total_breakspecial = quantity_breakfastspecial * breakfastspecial,
            hasbrownandegg,
            quantity_hasbrownandegg,
            total_hasbrownandegg = quantity_hasbrownandegg * hasbrownandegg,
            sundayspecial,
            quantity_sundayspecial,
            total_sundayspecial = quantity_sundayspecial * sundayspecial,
            apple,
            quantity_apple,
            total_apple = quantity_apple * apple,
            grape,
            quantity_grape,
            total_grape = quantity_grape * grape,
            orange,
            quantity_orange,
            total_orange = quantity_orange * orange,
            cappachino,
            quantity_cappachino,
            total_cappachino = quantity_cappachino * cappachino,
            hotchocolate,
            quantity_hotchocolate,
            total_hotchocolate = quantity_hotchocolate * hotchocolate,
            coffee,
            quantity_coffee,
            total_coffee = quantity_coffee * coffee,
            tea,
            quantity_tea,
            total_tea = quantity_tea * tea,
            beef,
            quantity_beef,
            total_beef = quantity_beef * beef,
            baconandcheese,
            quantity_baconandcheese,
            total_baconandcheese = quantity_baconandcheese * baconandcheese,
            chicken,
            quantity_chicken,
            total_chicken = quantity_chicken * chicken,
            cheese,
            quantity_cheese,
            total_cheese = quantity_cheese * cheese,
            smallchips,
            quantity_smallchips,
            total_smallchips = quantity_smallchips * smallchips,
            mediumchips,
            quantity_mediumchips,
            total_mediumchips = quantity_mediumchips * mediumchips,
            largechips,
            quantity_largechips,
            total_largechips = largechips * quantity_largechips,
            megachips,
            quantity_megachips,
            total_megachips = megachips * quantity_megachips,
            softdrink,
            quantity_softdrinks,
            total_softdrinks = softdrink * quantity_softdrinks,
            milkshake,
            quantity_milkshakes,
            total_milkshakes = milkshake * quantity_milkshakes;

        public static List<int> PricesOfItemsChosen = new List<int>();
        public static List<string> ItemsAdded = new List<string>();

        static void TotalAmountToPay() { 
            PricesOfItemsChosen.Add(total_breakspecial); 
            PricesOfItemsChosen.Add(total_hasbrownandegg); 
            PricesOfItemsChosen.Add(total_sundayspecial); 
            PricesOfItemsChosen.Add(total_breakspecial); 
            PricesOfItemsChosen.Add(total_apple); 
            PricesOfItemsChosen.Add(total_grape); 
            PricesOfItemsChosen.Add(total_orange); 
            PricesOfItemsChosen.Add(total_cappachino); 
            PricesOfItemsChosen.Add(total_hotchocolate); 
            PricesOfItemsChosen.Add(total_coffee); 
            PricesOfItemsChosen.Add(total_tea); 
            PricesOfItemsChosen.Add(total_beef); 
            PricesOfItemsChosen.Add(total_baconandcheese); 
            PricesOfItemsChosen.Add(total_chicken); 
            PricesOfItemsChosen.Add(total_cheese); 
            PricesOfItemsChosen.Add(total_largechips); 
            PricesOfItemsChosen.Add(total_mediumchips); 
            PricesOfItemsChosen.Add(total_softdrinks); 
            PricesOfItemsChosen.Add(total_milkshakes); 
            topay1 = total_breakspecial + total_hasbrownandegg + total_sundayspecial + total_apple + total_grape + total_orange + total_cappachino + total_hotchocolate + total_coffee + total_tea + total_beef + total_beef + total_baconandcheese + total_chicken + total_cheese + largechips + total_mediumchips + total_softdrinks; 
            
            Console.Clear(); Console.WriteLine("the total amount to pay is : " + topay1); 
            Console.WriteLine("====You Orderd:===="); 
            
            for (int i = 0; i < Totle_order; i++) {Console.WriteLine(ItemsAdded[i]); } } 
        
            enum Menu { Breakfast = 1, Combos, Chips, Burgers, Drinks, Checkout } 
            enum Breakfast { Breakfast = 1, Hasbrown, Sunday, Back } 
            enum Chips { Small = 1, Medium, Large, Mega, Back } 
            enum Burgers { Beef = 1, Cheese, Bacon, Chicken, Back } 
            enum Drinks { Soft = 1, Milkshake, Juice, Hot, Back } 
            enum Hotdrinks { cappachino = 1, hotchocolate, coffee, tea } 
            enum juice { apple = 1, grape, orange } 
           
            static void Main(string[] args) { 
            bool back1 = true; 
            bool back2 = false; 
            bool back3 = false; 
            bool back4 = false; 

            do { 
                Console.WriteLine("Menu");
                foreach (Menu choice in Enum.GetValues(typeof(Menu))) { 
                    Console.WriteLine((int)choice + ". " + choice.ToString()); } 
                
                Console.WriteLine("Please make your choice:"); 
                int pick = Convert.ToInt32(Console.ReadLine());  
                
                switch (pick) { 
                    case 1: Console.Clear(); BreakfastNext1(back1); 
                            break; 
                    case 2: Console.WriteLine("we are out of stock on Combos"); 
                            break; 
                    case 3: Console.Clear(); ChipsNext1(back2); 
                            break; 
                    case 4: Console.Clear(); BurgersNext1(back3); 
                            break; 
                    case 5: Console.Clear(); DrinksNext1(back4); 
                            break; 
                    case 6: TotalAmountToPay(); 
                            break; 
                    default: break; } } 
                while (back1 == true); 
                Console.ReadKey(); } 
        
        static void BreakfastNext1(bool back1) { 
            Console.WriteLine("Breakfast"); 
            Console.WriteLine((int)Breakfast.Breakfast + ". " + Breakfast.Breakfast.ToString() + " Special R40");
            Console.WriteLine((int)Breakfast.Hasbrown + ". " + Breakfast.Hasbrown.ToString() + " and egg R20"); 
            Console.WriteLine((int)Breakfast.Sunday + ". " + Breakfast.Sunday.ToString() + " Special R60"); 
            Console.WriteLine((int)Breakfast.Back + ". " + Breakfast.Back.ToString()); 
            Console.WriteLine("Please make your choice:"); 
            int choice1 = Convert.ToInt32(Console.ReadLine()); 

            switch (choice1) { 

                case 1: back1 = false; 
                        Console.WriteLine("How many breakfast specials would you like to order? "); 
                        breakfastspecial = 40; 
                        quantity_breakfastspecial = int.Parse(Console.ReadLine()); 
                        total_breakspecial = quantity_breakfastspecial * breakfastspecial; 
                        Console.WriteLine("that will be " + total_breakspecial); 
                        ItemsAdded.Add("Breakfast special"); Totle_order = Totle_order + 1; 
                        break; 

                case 2: back1 = false; Console.WriteLine("How many hasbrowns and eggs would you like to order?");
                        hasbrownandegg = 24; 
                        quantity_hasbrownandegg = int.Parse(Console.ReadLine()); 
                        total_hasbrownandegg = quantity_hasbrownandegg * hasbrownandegg; 
                        Console.WriteLine("that will be " + total_hasbrownandegg); 
                        ItemsAdded.Add("Hasbrown&Egg"); 
                        Totle_order = Totle_order + 1; 
                        break; 

                case 3: back1 = false; 
                        Console.WriteLine("How many Breakfast Specials would you like?"); 
                        sundayspecial = 24; 
                        quantity_sundayspecial = int.Parse(Console.ReadLine()); 
                        total_sundayspecial = quantity_breakfastspecial * breakfastspecial; 
                        Console.WriteLine("that will be " + total_sundayspecial); 
                        Totle_order = Totle_order + 1; 
                        ItemsAdded.Add("Breakfast Specials"); 
                        break; 
                
                case 4: back1 = true; 
                        break; 
               
                default: break; } } 
        
        static void ChipsNext1(bool back2) { 
                Console.WriteLine("Chips"); 
                Console.WriteLine((int)Chips.Small + ". " + Chips.Small.ToString() + " fried chips = R20"); 
                Console.WriteLine((int)Chips.Medium + ". " + Chips.Medium.ToString() + " fried chips = R50"); 
                Console.WriteLine((int)Chips.Large + ". " + Chips.Large.ToString() + " fried chips = R80"); 
                Console.WriteLine((int)Chips.Mega + ". " + Chips.Mega.ToString() + " fried chips = R120"); 
                Console.WriteLine((int)Chips.Back + ". " + Chips.Back.ToString()); 
                int choice2 = Convert.ToInt32(Console.ReadLine()); 
                
            switch (choice2) { 
                case 1: back2 = false; 
                        Console.WriteLine(" how many small chips do you want "); 
                        smallchips = 24; 
                        quantity_smallchips = int.Parse(Console.ReadLine()); 
                        total_smallchips = smallchips * quantity_smallchips; 
                        Console.WriteLine("that will be " + total_smallchips); 
                        ItemsAdded.Add("Small Chips"); 
                        Totle_order = Totle_order + 1; 
                        break; 
               
                case 2: back2 = false; 
                        Console.WriteLine("how may medium chips do you want "); 
                        mediumchips = 24; 
                        quantity_mediumchips = int.Parse(Console.ReadLine()); 
                        total_mediumchips = megachips * quantity_mediumchips; 
                        Console.WriteLine("that will be " + mediumchips); 
                        ItemsAdded.Add("Medium Chips"); 
                        Totle_order = Totle_order + 1; 
                        break; 
                
                case 3: back2 = false; 
                        Console.WriteLine(" how many large chips do you want "); 
                        largechips = 23; 
                        quantity_largechips = int.Parse(Console.ReadLine()); 
                        total_largechips = int.Parse(Console.ReadLine()); 
                        Console.WriteLine("that will be " + total_largechips); 
                        ItemsAdded.Add("Large Chips"); 
                        Totle_order = Totle_order + 1; 
                        break; 
               
                case 4: back2 = false; 
                        Console.WriteLine(" how many mega chips do you want "); 
                        megachips = 24; 
                        quantity_megachips = int.Parse(Console.ReadLine()); 
                        total_mediumchips = quantity_megachips * megachips; 
                        Console.WriteLine("that will be " + megachips); 
                        ItemsAdded.Add("Large Chips"); 
                        Totle_order = Totle_order + 1;
                        break;
                default: break; } } 
        
        static void BurgersNext1(bool back3) { 
            
            Console.WriteLine("Burgers"); 
            Console.WriteLine((int)Burgers.Beef + ". " + Burgers.Beef.ToString() + " Burger = R154,90"); 
            Console.WriteLine((int)Burgers.Cheese + ". " + Burgers.Cheese.ToString() + " Burger = R169,90"); 
            Console.WriteLine((int)Burgers.Bacon + ". " + Burgers.Beef.ToString() + " and Cheese Burger = R179,90"); 
            Console.WriteLine((int)Burgers.Chicken + ". " + Burgers.Chicken.ToString() + " Burger = R159,90"); 
            Console.WriteLine((int)Burgers.Back + ". " + Burgers.Back.ToString()); 
            Console.WriteLine("Please make your choice:"); 
            int choice3 = Convert.ToInt32(Console.ReadLine()); 
            
            switch (choice3) { 

                case 1: back3 = false; 
                        Console.WriteLine("how many beef burgers do you want "); 
                        beef = 26; quantity_beef = int.Parse(Console.ReadLine()); 
                        total_beef = beef * quantity_beef; 
                        Console.WriteLine("that will be " + total_beef); 
                        ItemsAdded.Add("Beef Burger"); 
                        Totle_order = Totle_order + 1; 
                        break;
                    
                case 2: back3 = false; 
                        Console.WriteLine("how many cheese burgers do you want "); 
                        cheese = 56; 
                        quantity_cheese = int.Parse(Console.ReadLine()); 
                        total_cheese = quantity_cheese * cheese; 
                        Console.WriteLine("that will be " + total_cheese); 
                        ItemsAdded.Add("Cheese Burger"); 
                        Totle_order = Totle_order + 1; 
                        break; 
               
                case 3: back3 = false; 
                        Console.WriteLine("how many bacon and cheese burgers do you want "); 
                        baconandcheese = 25; quantity_baconandcheese = int.Parse(Console.ReadLine()); 
                        total_baconandcheese = baconandcheese * quantity_baconandcheese; 
                        Console.WriteLine("that will be " + total_baconandcheese); 
                        ItemsAdded.Add("Bacon&Cheese Burger"); 
                        Totle_order = Totle_order + 1; 
                        break; 
               
                case 4: back3 = false; 
                        Console.WriteLine("how many chicken burgers do you want "); 
                        chicken = 45; 
                        quantity_chicken = int.Parse(Console.ReadLine()); 
                        total_chicken = chicken * quantity_chicken; 
                        Console.WriteLine("that will be " + total_chicken); 
                        ItemsAdded.Add("Chicken Burger"); 
                        Totle_order = Totle_order + 1; 
                        break; 
                
                case 5: back3 = true; 
                        break; 
               
                default: break; } } 
        
        static void DrinksNext1(bool back4) { 
                
            Console.WriteLine("Drinks"); 
            Console.WriteLine((int)Drinks.Soft + ". " + Drinks.Soft.ToString() + " Drinks"); 
            Console.WriteLine((int)Drinks.Milkshake + ". " + Drinks.Milkshake.ToString()); 
            Console.WriteLine((int)Drinks.Juice + ". " + Drinks.Juice.ToString()); 
            Console.WriteLine((int)Drinks.Hot + ". " + Drinks.Hot.ToString() + " Drinks"); 
            Console.WriteLine((int)Drinks.Back + ". " + Drinks.Back.ToString()); 
            Console.WriteLine("Please make your choice:"); 
            int choice4 = Convert.ToInt32(Console.ReadLine()); 
          
        switch (choice4) { 
                
                case 1: back4 = false; 
                        Console.WriteLine("how many softdrinks do you want "); 
                        softdrink = 24; quantity_softdrinks = int.Parse(Console.ReadLine()); 
                        total_softdrinks = quantity_softdrinks * softdrink; 
                        Console.WriteLine("that will be " + total_softdrinks); 
                        ItemsAdded.Add("Soft drinks"); 
                        Totle_order = Totle_order + 1; 
                        break; 
                
                case 2: back4 = false; 
                        Console.WriteLine("how many milkshakes do you want"); 
                        milkshake = 24; 
                        quantity_milkshakes = Convert.ToInt32(Console.ReadLine()); 
                        total_milkshakes = quantity_milkshakes * milkshake; 
                        Console.WriteLine("that will be " + total_milkshakes); 
                        ItemsAdded.Add("Milk Shakes"); 
                        Totle_order = Totle_order + 1; 
                        break; 
                
                case 3: back4 = false; 
                        Console.WriteLine("juices"); 
                        
                        foreach (juice choice in Enum.GetValues(typeof(juice))) {Console.WriteLine((int)choice + ". " + choice.ToString()); } 
                        
                        Console.WriteLine("Please make your choice:"); 
                        int juicechoice = Convert.ToInt32(Console.ReadLine()); 
                            
                            switch (juicechoice) { 
                                case 1: Console.WriteLine("how many apple juices do you want "); 
                                        apple = 40; 
                                        quantity_apple = Convert.ToInt32(Console.ReadLine()); 
                                        total_apple = quantity_apple * apple; 
                                        Console.WriteLine("that will be " + total_apple); 
                                        ItemsAdded.Add("Apple Juice"); Totle_order = Totle_order + 1; 
                                        break; 
                        
                                case 2: Console.WriteLine("how many grape juices do you want "); 
                                        grape = 25; quantity_grape = Convert.ToInt32(Console.ReadLine()); 
                                        total_grape = quantity_grape * grape; 
                                        Console.WriteLine("that will be " + total_grape); 
                                        ItemsAdded.Add("Grape Juice"); 
                                        Totle_order = Totle_order + 1; 
                                        break; 
                        
                                case 3: Console.WriteLine(" how many orange juices do you want "); 
                                        orange = 25; 
                                        quantity_orange = Convert.ToInt32(Console.ReadLine()); 
                                        total_orange = quantity_orange * orange; 
                                        Console.WriteLine("that will be " + total_orange); 
                                        ItemsAdded.Add("Orange Juice"); Totle_order = Totle_order + 1; 
                                        break; }                       
                            break; 
                
                case 4: back4 = false; 
                        Console.WriteLine("hot drinks"); 
                        
                        foreach (Hotdrinks choice in Enum.GetValues(typeof(Hotdrinks))) {Console.WriteLine((int)choice + ". " + choice.ToString()); } 
                    
                        Console.WriteLine("Please make your choice:"); 
                        int hotdrink_choice = Convert.ToInt32(Console.ReadLine()); 
                    
                        switch (hotdrink_choice) { 
                            
                            case 1: Console.WriteLine(" how many cups of cappchino do you want"); 
                                    cappachino = 25; 
                                    quantity_cappachino = Convert.ToInt32(Console.ReadLine()); 
                                    total_cappachino = cappachino * quantity_cappachino; 
                                    Console.WriteLine("that will be " + total_cappachino); 
                                    ItemsAdded.Add("Cuppachino"); 
                                    Totle_order = Totle_order + 1; 
                                    break; 
                            
                            case 2: Console.WriteLine("how many cups hot chocolate "); 
                                    hotchocolate = 27; 
                                    quantity_hotchocolate = int.Parse(Console.ReadLine());  
                                    total_hotchocolate = quantity_hotchocolate * quantity_hotchocolate; 
                                    Console.WriteLine("that will be " + total_hotchocolate); 
                                    ItemsAdded.Add("Hot Chocolate"); Totle_order = Totle_order + 1; 
                                    break; 
                        
                            case 3: Console.WriteLine("how many cups of coffee"); 
                                    coffee = 34; 
                                    quantity_coffee = int.Parse(Console.ReadLine()); 
                                    total_coffee = coffee * quantity_coffee; 
                                    Console.WriteLine("that will be " + total_coffee); 
                                    ItemsAdded.Add("Coffee"); Totle_order = Totle_order + 1; 
                                    break; 
                            
                            case 4: Console.WriteLine("how many cups of tea "); 
                                    tea = 32; 
                                    quantity_tea = int.Parse(Console.ReadLine()); 
                                    total_tea = tea * quantity_tea; 
                                    Console.WriteLine("that will be " + total_tea); 
                                    ItemsAdded.Add("Tea"); Totle_order = Totle_order + 1; 
                                    break; } 
                        break; 
                
                case 5: back4 = true; 
                        break; 
                
                default: break; } } } }
